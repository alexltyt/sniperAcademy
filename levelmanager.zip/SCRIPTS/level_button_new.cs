﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class level_button_new : MonoBehaviour
{
    public Text LevelText;
    public int unlocked;
}
