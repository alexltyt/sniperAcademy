﻿using UnityEngine;

public class Level_scelector : MonoBehaviour {



public void Select(string levelName)
    {

    }
}
